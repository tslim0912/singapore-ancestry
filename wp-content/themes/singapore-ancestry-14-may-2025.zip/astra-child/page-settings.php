<?php
/*
 * Template name: System - Settings
 *
 *
 *
*/

get_template_part('header-admin');
?>
<div id="primary" class="main-content">
    <?php get_template_part('template-parts/admin/admin-page-template', 'settings');?>
</div>
<?php
get_template_part('footer-admin');
?>