<?php
/*
 * Template name: System - Login
 *
 *
 *
*/

get_template_part('header-admin');
?>
    <div id="primary" class="main-content">
        <?php get_template_part('template-parts/admin/admin-page-template', 'login'); ?>
    </div>
<?php
get_template_part('footer-admin');
?>
