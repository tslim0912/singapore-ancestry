<?php
/*
 * Template name: System - Dashboard
 *
 *
 *
*/

get_template_part('header-admin');
?>
<div id="primary" class="main-content">
    <?php get_template_part('template-parts/admin/admin-page-template', 'dashboard');?>
</div>
<?php
get_template_part('footer-admin');
?>