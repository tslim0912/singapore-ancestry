<?php
/*
 * Template name: System - Profile
 *
 *
 *
*/

get_template_part('header-admin');
?>
<div id="primary" class="main-content">
    <?php get_template_part('template-parts/admin/admin-page-template', 'profile');?>
</div>
<?php
get_template_part('footer-admin');
?>
