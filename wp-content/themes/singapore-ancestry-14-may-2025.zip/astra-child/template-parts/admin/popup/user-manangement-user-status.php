<div class="sg-popup">
    <div class="sg-popup-inner">
        <div class="sg-popup-body">

        </div>
        <button type="button" class="sg-close"><span class="d-none">Close</span></button>
    </div>
</div>