
<div class="app-title">
    <h3>Hey!<br/>Welcome to Singapore Ancestry!</h3>
    <p>Log in to access your profile</p>
</div>
<div class="app-content">
    <div class="signin-menu">
        <div class="signin-option">
            <button type="button" class="btn btn-solid btn-template" id="btn-register" data-method="register"><span>Get Started</span></button>
        </div>
        <div class="signin-option">
            <button type="button" class="btn btn-outline btn-template" id="btn-signin" data-method="login"><span>I already have an account</span></button>
        </div>
    </div>
    <div class="error"></div>
</div>